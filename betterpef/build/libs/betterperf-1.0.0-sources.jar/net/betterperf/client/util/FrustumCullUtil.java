package net.betterperf.client.util;

import net.betterperf.BetterPerfConfig;
import net.betterperf.client.mixin.LevelRendererFrustumAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_4604;
import net.minecraft.class_761;

public final class FrustumCullUtil {
	private static final BetterPerfConfig CONFIG = BetterPerfConfig.DEFAULT;

	private FrustumCullUtil() {
	}

	public static boolean isOutsideCameraFrustum(class_1297 entity) {
		class_310 minecraft = class_310.method_1551();
		class_761 levelRenderer = minecraft.field_1769;

		if (levelRenderer == null) {
			return false;
		}

		class_4604 frustum = resolveActiveFrustum(levelRenderer);
		if (frustum == null) {
			return false;
		}

		double inflate = CONFIG.entityCullBoxInflate();
		class_238 bounds = entity.method_5829().method_1009(inflate, inflate, inflate);
		return !frustum.method_23093(bounds);
	}

	private static class_4604 resolveActiveFrustum(class_761 levelRenderer) {
		return ((LevelRendererFrustumAccessor) levelRenderer).betterperf$getCullingFrustum();
	}
}
