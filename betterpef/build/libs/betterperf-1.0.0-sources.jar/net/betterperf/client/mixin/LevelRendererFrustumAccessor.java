package net.betterperf.client.mixin;

import net.minecraft.class_4604;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface LevelRendererFrustumAccessor {
	@Accessor("cullingFrustum")
	class_4604 betterperf$getCullingFrustum();
}
