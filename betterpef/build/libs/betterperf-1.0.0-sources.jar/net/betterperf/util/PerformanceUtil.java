package net.betterperf.util;

import net.betterperf.BetterPerfConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

public final class PerformanceUtil {
	private PerformanceUtil() {
	}

	public static boolean noPlayerNearby(class_1297 entity, double maxDistance) {
		class_1937 level = entity.method_37908();
		class_1657 nearest = level.method_18460(entity, maxDistance);
		return nearest == null;
	}

	public static boolean shouldThrottleAiTick(class_1297 entity, BetterPerfConfig config) {
		return noPlayerNearby(entity, config.aiThrottleDistanceBlocks())
				&& entity.field_6012 % config.aiThrottleIntervalTicks() != 0;
	}
}
