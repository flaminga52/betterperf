package net.betterperf.mixin.accessor;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3558.class)
public interface LightEngineAccessor {
	@Invoker("getState")
	class_2680 betterperf$getState(class_2338 pos);
}
