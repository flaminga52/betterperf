package net.betterperf.mixin;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import net.betterperf.mixin.accessor.LightEngineAccessor;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3558;
import net.minecraft.class_3568;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Skips redundant light updates when the block at a position has not changed.
 * <p>
 * Hooks {@link class_3568#method_15513(class_2338)} instead of the abstract
 * {@link class_3558#method_51529(long)} so the injection has a concrete method body.
 * Caching the last block id per position avoids re-running block and sky light
 * propagation for static farm builds where lighting is already settled.
 */
@Mixin(class_3568.class)
public class LevelLightEngineOptimizeMixin {
	private static final int CACHE_CAPACITY = 16_384;

	@Shadow
	@Final
	private class_3558<?, ?> blockEngine;

	@Unique
	private static final Long2IntOpenHashMap betterperf$blockStateCache = new Long2IntOpenHashMap();

	@Inject(method = "checkBlock", at = @At("HEAD"), cancellable = true)
	private void betterperf$skipUnchangedLightCheck(class_2338 pos, CallbackInfo ci) {
		class_2680 state = ((LightEngineAccessor) this.blockEngine).betterperf$getState(pos);
		int stateId = class_2248.method_9507(state);
		long key = pos.method_10063();

		int previous = betterperf$blockStateCache.getOrDefault(key, -1);
		if (previous == stateId) {
			ci.cancel();
			return;
		}

		if (betterperf$blockStateCache.size() >= CACHE_CAPACITY) {
			betterperf$blockStateCache.clear();
		}

		betterperf$blockStateCache.put(key, stateId);
	}
}
